const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const Hotel = require('../models/hotelModel');
const Donation = require('../models/donationModel');
const NGO = require('../models/ngoModel');
const Report = require('../models/reportModel');
const geolib = require('geolib');

// Controller to register a new hotel
exports.registerHotel = async (req, res) => {
  try {
    const { name, email, password, address,locationType,locationCoordinates, city, state, pincode, contactPerson, contactNumber } = req.body;
     // Ensure location data is provided in the correct format
     let location;
     if (Array.isArray(locationCoordinates) && locationCoordinates.length === 2 && locationCoordinates.every(isFinite)) {
       location = {
         type: locationType,
         coordinates: locationCoordinates
       };
     } else {
       // Return an error response if location coordinates are invalid
       return res.status(400).json({ success: false, message: "Invalid location coordinates provided" });
     }
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const hotel = await Hotel.create({
      name,
      email,
      password: hashedPassword, // Store the hashed password
      address,
      location,
      city,
      state,
      pincode,
      contactPerson,
      contactNumber,
    });

    res.status(201).json({ success: true, hotel });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

//  Controller for hotel login
// exports.loginHotel = async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     // Find the hotel by email
//     const hotel = await Hotel.findOne({ email });

//     // If hotel not found
//     if (!hotel) {
//       return res.status(401).json({ success: false, message: 'Invalid email or password' });
//     }

//     // Compare the provided password with the stored hashed password
//     const isPasswordValid = await bcrypt.compare(password, hotel.password);

//     // If password is incorrect
//     if (!isPasswordValid) {
//       return res.status(401).json({ success: false, message: 'Invalid email or password' });
//     }

//     // Generate a JSON Web Token
//     const token = jwt.sign({ id: hotel._id }, process.env.JWT_SECRET, {
//       expiresIn: '1h', // Token expiration time
//     });

//     res.status(200).json({ success: true, token });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// Controller to get all hotels
exports.getAllHotels = async (req, res) => {
  try {
    const hotels = await Hotel.find();
    res.status(200).json({ success: true, hotels });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to get a hotel by ID
exports.getHotelById = async (req, res) => {
  try {
    const hotel = await Hotel.findById(req.params.id);
    if (!hotel) {
      return res.status(404).json({ success: false, message: 'Hotel not found' });
    }
    res.status(200).json({ success: true, hotel });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to update a hotel
exports.updateHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!hotel) {
      return res.status(404).json({ success: false, message: 'Hotel not found' });
    }
    res.status(200).json({ success: true, hotel });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to delete a hotel
exports.deleteHotel = async (req, res) => {
  try {
    const hotel = await Hotel.findByIdAndDelete(req.params.id);
    if (!hotel) {
      return res.status(404).json({ success: false, message: 'Hotel not found' });
    }
    res.status(200).json({ success: true, message: 'Hotel deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller for Hotel Dashboard
exports.hotelDashboard = async (req, res) => {
  try {
    const hotelId = req.query.id;
    // Find donations made by this hotel
    const donations = await Donation.find({ hotelId });
    // Find pending requests for donations made by this hotel
    const pendingRequests = donations.filter(donation => donation.requests.length > 0);
    res.status(200).json({ success: true, data: { donations, pendingRequests, donationCount: donations.length } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
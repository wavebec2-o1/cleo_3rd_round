const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const NGO = require('../models/ngoModel');
const Donation = require('../models/donationModel');

// Controller to register a new NGO
exports.registerNGO = async (req, res) => {
  try {
    const { name, email, password, address, city, state, pincode, contactPerson, contactNumber, locationType,locationCoordinates } = req.body;
    // Ensure location data is provided in the correct format
    console.log(req.body)
    let location;
    if (Array.isArray(locationCoordinates) && locationCoordinates.length === 2 && locationCoordinates.every(coord => !isNaN(coord))) {
      location = {
        type: locationType,
        coordinates: locationCoordinates.map(Number) 
      };
    } else {
      console.error('Invalid location coordinates:', locationCoordinates);
      // Return an error response if location coordinates are invalid
      return res.status(400).json({ success: false, message: "Invalid location coordinates provided" });
    }
    console.log(location)
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const ngo = await NGO.create({
      name,
      email,
      password: hashedPassword, // Store the hashed password
      address,
      city,
      state,
      pincode,
      contactPerson,
      contactNumber,
      location,
    });

    res.status(201).json({ success: true, ngo });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller for NGO login
// exports.loginNGO = async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     // Find the NGO by email
//     const ngo = await NGO.findOne({ email });

//     // If NGO not found
//     if (!ngo) {
//       return res.status(401).json({ success: false, message: 'Invalid email or password' });
//     }

//     // Compare the provided password with the stored hashed password
//     const isPasswordValid = await bcrypt.compare(password, ngo.password);

//     // If password is incorrect
//     if (!isPasswordValid) {
//       return res.status(401).json({ success: false, message: 'Invalid email or password' });
//     }

//     // Generate a JSON Web Token
//     const token = jwt.sign({ id: ngo._id }, process.env.JWT_SECRET, {
//       expiresIn: '1h', // Token expiration time
//     });

//     res.status(200).json({ success: true, token });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// Controller to get all NGOs
exports.getAllNGOs = async (req, res) => {
  try {
    const ngos = await NGO.find();
    res.status(200).json({ success: true, ngos });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to get an NGO by ID
exports.getNGOById = async (req, res) => {
  try {
    const ngo = await NGO.findById(req.params.id);
    if (!ngo) {
      return res.status(404).json({ success: false, message: 'NGO not found' });
    }
    res.status(200).json({ success: true, ngo });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to update an NGO
exports.updateNGO = async (req, res) => {
  try {
    const ngo = await NGO.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!ngo) {
      return res.status(404).json({ success: false, message: 'NGO not found' });
    }
    res.status(200).json({ success: true, ngo });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to delete an NGO
exports.deleteNGO = async (req, res) => {
  try {
    const ngo = await NGO.findByIdAndDelete(req.params.id);
    if (!ngo) {
      return res.status(404).json({ success: false, message: 'NGO not found' });
    }
    res.status(200).json({ success: true, message: 'NGO deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Controller to request a donation from a hotel
exports.requestDonation = async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const { donationId } = req.body;
      const ngoId = req.query.id;
  
      if (!mongoose.Types.ObjectId.isValid(donationId)) {
        return res.status(400).json({ success: false, message: 'Invalid donation ID' });
      }
  
      const donation = await Donation.findById(donationId).session(session);
      if (!donation) {
        return res.status(404).json({ success: false, message: 'Donation not found' });
      }
  
      // Check if the NGO has already requested this donation
      if (donation.requests.includes(ngoId)) {
        return res.status(400).json({ success: false, message: 'Donation already requested' });
      }
  
      donation.requests.push(ngoId);
      await donation.save({ session });
  
      const ngo = await NGO.findByIdAndUpdate(ngoId, { $push: { requestedDonations: donationId } }, { new: true, session });
  
      await session.commitTransaction();
      session.endSession();
  
      res.status(200).json({ success: true, ngo });
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      res.status(500).json({ success: false, message: error.message });
    }
  };

  // Controller for NGO Dashboard
exports.ngoDashboard = async (req, res) => {
    try {
      const ngoId = req.query.id; 
  
      // Find the NGO's details
      const ngo = await NGO.findById(ngoId).populate('requestedDonations');
  
      // Find donations approved for this NGO
      const approvedDonations = await Donation.find({ approvedNgo: ngoId });
  
      res.status(200).json({ 
        success: true, 
        data: {
          requestedDonations: ngo.requestedDonations,
          approvedDonations,
          requestedDonationCount: ngo.requestedDonations.length,
          approvedDonationCount: approvedDonations.length
        }
      });
    } catch (error) {
      res.status(500).json({ success: false, message: error.message });
    }
  };
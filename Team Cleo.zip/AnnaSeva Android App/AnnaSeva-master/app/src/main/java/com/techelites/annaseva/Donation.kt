package com.techelites.annaseva

data class DonationH(
    val _id: String,
    val name: String,
    val createdAt: String
)

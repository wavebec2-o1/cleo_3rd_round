package com.techelites.annaseva


data class Requestt(
    val _id: String,
    val ngo: NGO,
    val donation: String,
    val status: String
)



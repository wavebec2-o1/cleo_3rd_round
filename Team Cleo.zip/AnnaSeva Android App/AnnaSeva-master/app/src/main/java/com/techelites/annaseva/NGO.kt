package com.techelites.annaseva

data class NGO(
    val _id: String,
    val name: String
)